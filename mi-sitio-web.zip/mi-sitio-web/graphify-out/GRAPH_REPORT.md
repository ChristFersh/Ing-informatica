# Graph Report - mi-sitio-web  (2026-11-10)

## Corpus Check
- 2 files · ~11,351 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 20 nodes · 23 edges · 3 communities (2 shown, 1 thin omitted)
- Extraction: 100% EXTRACTED · 0% INFERRED · 0% AMBIGUOUS
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `64ba161f`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- main.js
- Mi página web personal — Christian Diaz
- aplicarTema

## God Nodes (most connected - your core abstractions)
1. `Mi página web personal — Christian Diaz` - 8 edges
2. `validarFormulario()` - 5 edges
3. `aplicarTema()` - 2 edges
4. `cambiarTema()` - 2 edges
5. `mostrarError()` - 2 edges
6. `limpiarError()` - 2 edges
7. `esCorreoValido()` - 2 edges
8. `enviarFormulario()` - 2 edges
9. `Íconos (web component de Iconify)` - 1 edges
10. `Cómo abrirlo` - 1 edges

## Surprising Connections (you probably didn't know these)
- None detected - all connections are within the same source files.

## Import Cycles
- None detected.

## Communities (3 total, 1 thin omitted)

### Community 0 - "main.js"
Cohesion: 0.33
Nodes (5): enviarFormulario(), esCorreoValido(), limpiarError(), mostrarError(), validarFormulario()

### Community 1 - "Mi página web personal — Christian Diaz"
Cohesion: 0.22
Nodes (8): Cómo abrirlo, Cómo cumple la rúbrica, Datos para revisar antes de entregar, Errores de la guía que se corrigieron, Estructura de archivos, Guía para la sustentación, Mi página web personal — Christian Diaz, Íconos (web component de Iconify)

## Knowledge Gaps
- **7 isolated node(s):** `Íconos (web component de Iconify)`, `Cómo abrirlo`, `Estructura de archivos`, `Cómo cumple la rúbrica`, `Errores de la guía que se corrigieron` (+2 more)
  These have ≤1 connection - possible missing edges or undocumented components. (Counts symbols only; 11 node(s) total have ≤1 connection when file, concept and rationale nodes are included.)
- **1 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **What connects `Íconos (web component de Iconify)`, `Cómo abrirlo`, `Estructura de archivos` to the rest of the system?**
  _7 weakly-connected nodes found - possible documentation gaps or missing edges._